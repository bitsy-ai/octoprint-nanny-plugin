#ifndef CXOVER_H
#define CXOVER_H

#define ATL_3NB 168
#define NN_MNK_M 5600
#define NN_MNK_N 32256
#define NN_MNK_MN 31360
#define NN_MNK_K 5600
#define NN_MNK_GE 3375
#define NT_MNK_M 32256
#define NT_MNK_N 32256
#define NT_MNK_MN 31360
#define NT_MNK_K 5600
#define NT_MNK_GE 13824
#define TN_MNK_M 5600
#define TN_MNK_N 32256
#define TN_MNK_MN 31360
#define TN_MNK_K 5600
#define TN_MNK_GE 13824
#define TT_MNK_M 32256
#define TT_MNK_N 32256
#define TT_MNK_MN 31360
#define TT_MNK_K 5600
#define TT_MNK_GE 13824
#define C2R_K 2147483647

#endif

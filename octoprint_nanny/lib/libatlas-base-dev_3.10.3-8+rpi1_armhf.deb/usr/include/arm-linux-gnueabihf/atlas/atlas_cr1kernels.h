/*
 * This file generated on line 730 of /build/atlas-jpV5es/atlas-3.10.3/build/..//tune/blas/ger/r1hgen.c
 */
#ifndef ATLAS_CR1KERNELS_H
   #define ATLAS_CR1KERNELS_H

void ATL_cgerk__2
   (ATL_CINT, ATL_CINT, const float*, const float*, float*, ATL_CINT);
void ATL_cgerk__2
   (ATL_CINT, ATL_CINT, const float*, const float*, float*, ATL_CINT);
void ATL_cgerk__2
   (ATL_CINT, ATL_CINT, const float*, const float*, float*, ATL_CINT);
void ATL_cgerk__2
   (ATL_CINT, ATL_CINT, const float*, const float*, float*, ATL_CINT);


#endif /* end guard around atlas_cr1kernels.h */

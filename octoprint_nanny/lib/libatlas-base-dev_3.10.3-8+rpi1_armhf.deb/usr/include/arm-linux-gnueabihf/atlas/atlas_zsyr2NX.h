#ifndef ATLAS_ZSYR2_H
   #define ATLAS_ZSYR2_H
   #define ATL_S2NX 88
#endif

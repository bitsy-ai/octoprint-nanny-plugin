#ifndef ATL_DSYSINFO_H
   #define ATL_DSYSINFO_H

#define ATL_MULADD
#define ATL_L1elts 2048
#define ATL_fplat  1
#define ATL_lbnreg 8
#define ATL_mmnreg 64
#define ATL_nkflop 449634

#endif
